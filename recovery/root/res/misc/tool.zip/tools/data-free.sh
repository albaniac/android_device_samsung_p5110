#!/sbin/busybox sh

# Ketut P. Kumajaya, May 2013

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep -c "/data") -lt 1 ]; then
  /sbin/mount /data
fi

FREESPACE=0
if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep -c "/.secondrom") -eq 1 ]; then
  FREESPACE=$(/sbin/busybox df | /sbin/busybox grep "/.secondrom" | /sbin/busybox awk '{printf $3}')
else
  FREESPACE=$(/sbin/busybox df | /sbin/busybox grep "/data" | /sbin/busybox awk '{printf $3}')
fi

if /sbin/busybox [ $FREESPACE -lt $1 ]; then
  exit 1
fi

exit 0
